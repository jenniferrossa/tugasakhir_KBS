from flask import Flask, render_template, request, jsonify
import csv, os

app = Flask(__name__)
CSV_FILE = 'data/student_data.csv'
FIELDNAMES = ['Student_ID','Age','Gender','Study_Hours_per_Week','Preferred_Learning_Style',
              'Online_Courses_Completed','Participation_in_Discussions',
              'Assignment_Completion_Rate (%)','Exam_Score (%)','Attendance_Rate (%)',
              'Use_of_Educational_Tech','Self_Reported_Stress_Level',
              'Time_Spent_on_Social_Media (hours/week)','Sleep_Hours_per_Night','Final_Grade']

def determine_learning_style(q1, q2, q3, q4):
    gaya = []
    if q1 == "Ya": gaya.append("Visual")
    if q2 == "Ya": gaya.append("Auditory")
    if q3 == "Ya": gaya.append("Reading/Writing")
    if q4 == "Ya": gaya.append("Kinesthetic")
    return "Multimodal" if len(gaya) == 4 else " - ".join(gaya) if gaya else "Tidak Teridentifikasi"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit', methods=['POST'])
def submit():
    form = request.json

    # Hitung Student ID
    if not os.path.exists(CSV_FILE):
        os.makedirs(os.path.dirname(CSV_FILE), exist_ok=True)
        with open(CSV_FILE, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()

    with open(CSV_FILE, 'r', newline='', encoding='utf-8') as f:
        reader = list(csv.DictReader(f))
        next_id = len(reader) + 1

    # Tentukan gaya belajar
    style = determine_learning_style(form['q1'], form['q2'], form['q3'], form['q4'])

    new_data = {
    'Student_ID': f'S{next_id}',  # ID dengan awalan 'S'
    'Age': form.get('age'),
    'Gender': form.get('gender'),
    'Study_Hours_per_Week': form.get('study_hours'),
    'Preferred_Learning_Style': style,
    'Online_Courses_Completed': form.get('courses'),
    'Participation_in_Discussions': form.get('discussion'),
    'Assignment_Completion_Rate (%)': form.get('assignment'),
    'Exam_Score (%)': form.get('exam'),
    'Attendance_Rate (%)': form.get('attendance'),
    'Use_of_Educational_Tech': form.get('tech'),
    'Self_Reported_Stress_Level': form.get('stress'),
    'Time_Spent_on_Social_Media (hours/week)': form.get('social'),
    'Sleep_Hours_per_Night': form.get('sleep'),
    'Final_Grade': form.get('grade')
    }



    with open(CSV_FILE, 'a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writerow(new_data)

    return jsonify({'message': 'Data berhasil disimpan!', 'style': style})

if __name__ == '__main__':
    app.run(debug=True)
