function submitForm() {
  const form = document.forms["formGayaBelajar"];
  const q1 = form["q1"].value;
  const q2 = form["q2"].value;
  const q3 = form["q3"].value;
  const q4 = form["q4"].value;

  if (!(q1 && q2 && q3 && q4)) {
    alert("Mohon isi semua pertanyaan.");
    return;
  }

  const gaya = [];
  if (q1 === "Ya") gaya.push("Visual");
  if (q2 === "Ya") gaya.push("Auditory");
  if (q3 === "Ya") gaya.push("Reading/Writing");
  if (q4 === "Ya") gaya.push("Kinesthetic");

  let hasil = "Tidak Teridentifikasi";
  if (gaya.length === 4) hasil = "Multimodal";
  else if (gaya.length > 0) hasil = gaya.join(" - ");

  document.getElementById("hasil").innerHTML = `Gaya Belajar Anda: <strong>${hasil}</strong>`;

  fetch("/add", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      visual: q1,
      auditory: q2,
      reading: q3,
      kinesthetic: q4,
      hasil: hasil
    })
  })
  .then(res => res.json())
  .then(() => fetchStats());
}

function fetchStats() {
  fetch("/get-stats")
    .then(res => res.json())
    .then(stats => {
      const container = document.getElementById("statistik");
      container.innerHTML = "";
      for (const key in stats) {
        container.innerHTML += `<p>${key}: ${stats[key]}</p>`;
      }
    });
}
